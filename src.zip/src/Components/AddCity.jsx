import React, {useState,useEffect} from 'react';
import axios from "axios";


export const AddCity = () => {
    const [city, setCity] = useState();
    const [population, setPopulation] = useState();
    const [country, setCountry] = useState();
    const [countryData, setCountryData] = useState([]);

    const data = {
        city: city,
        population: population,
        country: country,

    }

    const handleSubmit = () => {
        axios.post("http://localhost:8080/data", data).then((res) => {
            setCity(res.data)
        })
    }

    const handleChange = () =>{
         axios.get("http://localhost:8080/country").then((res)=>{
           console.log(res.data)
           setCountryData(res.data)
         })
    }

    useEffect(() =>{
        handleChange()
    },[])

    return (
        <div>
            <input type="text" placeholder="name" onChange={(e) => {setCity(e.target.value)}}/>
            <input type="text" placeholder="population" onChange={(e) => {setPopulation(e.target.value)}}/>
            {/* <input type="text" placeholder="country" onChange={(e) => {setCountry(e.target.value)}}/> */}
            <select onChange={handleChange}>
                {
                  countryData.map((e)=>{
                    return <option>{e.country}</option>
                  })
                }
            </select>
            <button onClick={handleSubmit}>submit</button>
        </div>
    )
}